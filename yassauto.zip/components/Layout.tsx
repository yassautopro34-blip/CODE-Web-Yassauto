import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, CarFront, Phone, PenTool, Home, Info, Settings, Wrench, Facebook, Instagram, Video } from 'lucide-react';

export const Layout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const location = useLocation();

  const closeMenu = () => setIsMenuOpen(false);

  const isActive = (path: string) => location.pathname === path ? "text-brand-red font-bold" : "text-zinc-300 hover:text-white";

  // Composant Logo personnalisé reproduisant l'image fournie (Engrenage, Voiture de face, Clé)
  // 100% Vectoriel (SVG) pour fond transparent et netteté parfaite
  const BrandLogo = () => (
    <div className="flex items-center gap-3 group">
      <div className="relative flex items-center justify-center w-14 h-14">
        {/* Engrenage (Arrière-plan) */}
        <Settings 
          className="absolute w-14 h-14 text-zinc-400 group-hover:text-white transition-colors duration-300" 
          strokeWidth={1.5} 
        />
        
        {/* Voiture de face (Au centre) */}
        <CarFront 
          className="absolute w-8 h-8 text-white mb-1" 
          strokeWidth={2.5} 
          fill="#18181B" 
        />
        
        {/* Clé à molette (En haut à gauche) */}
        <Wrench 
          className="absolute w-7 h-7 text-brand-red -top-1 -left-1 -rotate-45 transform" 
          strokeWidth={2.5} 
          fill="#DC2626"
        />
      </div>
      
      <div className="flex flex-col justify-center -space-y-1">
        <span className="text-2xl font-black text-white tracking-tighter italic leading-none">
          YASS<span className="text-brand-red">AUTO</span>
        </span>
      </div>
    </div>
  );

  return (
    <div className="flex flex-col min-h-screen bg-zinc-50">
      {/* Header */}
      <header className="fixed w-full top-0 z-50 bg-brand-black/95 backdrop-blur-sm border-b border-zinc-800 shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-20">
            <Link to="/" className="flex items-center" onClick={closeMenu}>
              <BrandLogo />
            </Link>

            {/* Desktop Nav */}
            <nav className="hidden md:flex space-x-8 items-center">
              <Link to="/" className={`text-sm uppercase tracking-wider transition-colors ${isActive('/')}`}>Accueil</Link>
              <Link to="/accompagnement" className={`text-sm uppercase tracking-wider transition-colors ${isActive('/accompagnement')}`}>Accompagnement</Link>
              <Link to="/mecanique" className={`text-sm uppercase tracking-wider transition-colors ${isActive('/mecanique')}`}>Mécanique</Link>
              <Link to="/propos" className={`text-sm uppercase tracking-wider transition-colors ${isActive('/propos')}`}>À Propos</Link>
              <Link to="/contact" className="bg-white text-brand-black hover:bg-zinc-200 px-4 py-2 rounded-md font-bold text-sm uppercase transition-colors">
                Contact
              </Link>
            </nav>

            {/* Mobile Menu Button */}
            <div className="md:hidden">
              <button
                onClick={() => setIsMenuOpen(!isMenuOpen)}
                className="text-white p-2 focus:outline-none"
              >
                {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Nav */}
        {isMenuOpen && (
          <div className="md:hidden bg-brand-black border-b border-zinc-800 absolute w-full shadow-xl">
            <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
              <Link to="/" onClick={closeMenu} className="flex items-center space-x-3 text-white hover:bg-zinc-800 block px-3 py-4 rounded-md text-base font-medium">
                <Home className="h-5 w-5 text-brand-red" />
                <span>Accueil</span>
              </Link>
              <Link to="/accompagnement" onClick={closeMenu} className="flex items-center space-x-3 text-white hover:bg-zinc-800 block px-3 py-4 rounded-md text-base font-medium">
                <CarFront className="h-5 w-5 text-brand-red" />
                <span>Accompagnement</span>
              </Link>
              <Link to="/mecanique" onClick={closeMenu} className="flex items-center space-x-3 text-white hover:bg-zinc-800 block px-3 py-4 rounded-md text-base font-medium">
                <PenTool className="h-5 w-5 text-brand-red" />
                <span>Mécanique</span>
              </Link>
              <Link to="/propos" onClick={closeMenu} className="flex items-center space-x-3 text-white hover:bg-zinc-800 block px-3 py-4 rounded-md text-base font-medium">
                <Info className="h-5 w-5 text-brand-red" />
                <span>À Propos</span>
              </Link>
              <Link to="/contact" onClick={closeMenu} className="flex items-center space-x-3 text-white hover:bg-zinc-800 block px-3 py-4 rounded-md text-base font-medium">
                <Phone className="h-5 w-5 text-brand-red" />
                <span>Contact</span>
              </Link>
            </div>
          </div>
        )}
      </header>

      {/* Main Content */}
      <main className="flex-grow pt-20">
        {children}
      </main>

      {/* Footer */}
      <footer className="bg-brand-black text-white py-12 border-t border-zinc-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="col-span-1 md:col-span-2">
              <BrandLogo />
              <p className="mt-6 text-zinc-400 text-sm max-w-sm">
                Expertise et accompagnement automobile à Montpellier. Nous vous aidons à acheter votre véhicule en toute confiance.
                <br /><br />
                Partenaire mécanique : <strong>Legna Auto</strong>
              </p>
            </div>
            <div>
              <h3 className="text-lg font-bold mb-4 text-brand-red">Services</h3>
              <ul className="space-y-2 text-zinc-400">
                <li><Link to="/accompagnement" className="hover:text-white">Accompagnement Achat</Link></li>
                <li><Link to="/mecanique" className="hover:text-white">Devis Mécanique</Link></li>
                <li><Link to="/contact" className="hover:text-white">Contact</Link></li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-bold mb-4 text-brand-red">Contact</h3>
              <ul className="space-y-2 text-zinc-400 text-sm">
                <li>Montpellier & Alentours</li>
                <li>06 12 34 56 78</li>
                <li>yassauto.pro34@gmail.com</li>
                <li className="flex space-x-4 mt-4">
                    {/* Social Icons */}
                    <a href="#" className="w-10 h-10 bg-zinc-800 rounded-lg flex items-center justify-center text-white hover:bg-brand-red hover:text-white transition-all duration-300">
                      <Instagram className="w-5 h-5" />
                    </a>
                    <a href="#" className="w-10 h-10 bg-zinc-800 rounded-lg flex items-center justify-center text-white hover:bg-brand-red hover:text-white transition-all duration-300">
                      <Video className="w-5 h-5" />
                    </a>
                    <a href="#" className="w-10 h-10 bg-zinc-800 rounded-lg flex items-center justify-center text-white hover:bg-brand-red hover:text-white transition-all duration-300">
                      <Facebook className="w-5 h-5" />
                    </a>
                </li>
              </ul>
            </div>
          </div>
          <div className="mt-12 pt-8 border-t border-zinc-800 text-center text-zinc-500 text-sm">
            <p>&copy; {new Date().getFullYear()} YassAuto. Tous droits réservés.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};