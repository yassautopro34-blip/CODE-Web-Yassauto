import React from 'react';
import { HashRouter, Routes, Route, ScrollRestoration } from 'react-router-dom';
import { Layout } from './components/Layout';
import { Home } from './pages/Home';
import { Accompagnement } from './pages/Accompagnement';
import { Mecanique } from './pages/Mecanique';
import { About } from './pages/About';
import { Contact } from './pages/Contact';

function App() {
  return (
    <HashRouter>
      <Layout>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/accompagnement" element={<Accompagnement />} />
          <Route path="/mecanique" element={<Mecanique />} />
          <Route path="/propos" element={<About />} />
          <Route path="/contact" element={<Contact />} />
        </Routes>
      </Layout>
    </HashRouter>
  );
}

export default App;